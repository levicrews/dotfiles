# ffloyd Metropolis

A reusable light Beamer theme based on [Metropolis](https://github.com/matze/mtheme),
using the approved ffloyd palettes. Choose warm cream, soft cream, or soft white; the selected
background applies to title, content, section, and standout slides.

- Default background: warm cream `#EDE8D9`.
- Optional background: soft cream `#F4F1EA`, the rounded sRGB midpoint between cream and soft white.
- Optional background: soft white `#FAFAFA`, matching original Metropolis.
- Body text: `#25606F`; headings and links: `#164C67`.
- `\alert{...}`, alert-block titles, and progress indicators: gold `#CB8A28`.
- Example blocks and primary list markers: green `#008464`.
- Filled blocks use subtle tints of their respective colors over the selected background.

## View the sample

[Cream sample deck](output/pdf/ffloyd_metropolis_demo.pdf) |
[Soft cream sample deck](output/pdf/ffloyd_metropolis_softcream_demo.pdf) |
[White sample deck](output/pdf/ffloyd_metropolis_white_demo.pdf).

[Cream preview](output/pdf/ffloyd_metropolis_preview.png) |
[Soft cream preview](output/pdf/ffloyd_metropolis_softcream_preview.png) |
[White preview](output/pdf/ffloyd_metropolis_white_preview.png).

The 16:9 deck includes title and section pages, nested bullet lists, a numbered
list, display mathematics, normal/alert/example blocks, a result table, a standout
slide, and three synthetic data visualizations:

1. **Categorical:** transport-mode shares, using all eight categorical colors.
2. **Sequential:** an availability-index heatmap with the seven ordered colors
   and one fixed 0-100 scale.
3. **Diverging:** signed changes in satisfaction, with all nine colors centered
   on zero and a visible marker for the near-zero cream value.

The data and uncertainty intervals are illustrative and do not represent a real
study. Chart PDFs contain vector artwork and embedded fonts. The `figures/`
directory includes cream chart assets, PNG previews, and synthetic CSV data.
Matching soft cream and white chart assets are in `figures/softcream/` and `figures/white/`.

## Use in another presentation

Copy these three files beside your `.tex` presentation, or install them together
on your TeX search path:

- `beamerthemeffloyd.sty`
- `beamercolorthemeffloyd.sty`
- `ffloyd_colors.tex`

```latex
\documentclass[10pt,aspectratio=169]{beamer}
\usetheme{ffloyd}
\title{Your presentation}
\begin{document}
\maketitle
\begin{frame}{A clear result}
  Body text with an \alert{important point}.
  \begin{exampleblock}{Example}
    Green identifies the example.
  \end{exampleblock}
\end{frame}
\end{document}
```

Metropolis must already be available in your TeX installation. LuaLaTeX or
XeLaTeX with Fira Sans and Fira Mono gives the intended Metropolis typography.
The theme does not change your global TeX installation or install fonts.

Standard Metropolis layout options work, for example:

```latex
\usetheme[progressbar=foot,numbering=none,block=transparent]{ffloyd}
```

Select a background in your preamble:

```latex
\usetheme[background=cream]{ffloyd} % #EDE8D9; also the default
% or
\usetheme[background=softcream]{ffloyd} % #F4F1EA
% or
\usetheme[background=white]{ffloyd} % #FAFAFA
```

You can also use `\metroset{background=white}`, `\metroset{background=softcream}`, or
`\metroset{background=cream}` after loading the theme, in the preamble.
`background=light` is an alias for cream. `ff_background` resolves to the selected
surface; `ff_background_cream`, `ff_background_softcream`, and `ff_background_white`
are also available as named colors. Text, alerts, and data colors are identical in all modes.

Embedded charts need to use the same background (or transparency). The demo
automatically selects the matching `figures/`, `figures/softcream/`, or `figures/white/` assets.

Defaults are a gold progress bar under the frame title, fractional slide
numbering, and filled blocks. Use `\metroset{...}` for subsequent layout or block
changes. This variant is designed for the light background; do not select
Metropolis's `background=dark` option.

## Build and regenerate

From this directory:

```sh
bash build.sh
bash build.sh --background softcream
bash build.sh --background white
# Or compile all three:
bash build.sh --background all
```

This uses `latexmk` and LuaLaTeX, keeps build files in `tmp/pdfs/`, and writes the
finished decks to `output/pdf/ffloyd_metropolis_demo.pdf` (cream),
`output/pdf/ffloyd_metropolis_softcream_demo.pdf` (soft cream), and
`output/pdf/ffloyd_metropolis_white_demo.pdf` (white). The prebuilt chart PDFs
for all backgrounds are included, so Python is not required just to compile.
The existing `--background both` option still builds cream and white only.

To regenerate the charts and their CSV data before compiling:

```sh
bash build.sh --charts
# Regenerate charts and compile all backgrounds:
bash build.sh --background all --charts
```

The chart generator requires Python 3, NumPy, and Matplotlib. It reads the color
definitions directly from the local `ffloyd_colors.tex`. The sequential and
diverging charts use discrete bins, preserving the exact approved swatch colors.
The random seed for the heatmap is fixed at 42.
All three variants use identical data. To generate charts alone, run
`python3 generate_charts.py --background cream`, `--background softcream`,
`--background white`, or `--background all`. `--background both` retains its
original meaning of cream and white only.

The palette file here is a byte-for-byte copy of `../ffloyd_colors.tex` when this
theme was created. This makes the theme portable. If you revise the parent
palette, copy it here and regenerate the charts to keep both in sync.

## Attribution

Metropolis: Copyright 2015 Matthias Vogelgesang and the LaTeX community.
[Full contributor list](https://github.com/matze/mtheme/graphs/contributors).
The original Metropolis template was based on HSRM by Benjamin Weiss.

This theme adaptation is licensed under
[Creative Commons Attribution-ShareAlike 4.0](https://creativecommons.org/licenses/by-sa/4.0/),
matching the upstream theme. The theme license does not impose that license on
presentations created with it. The ffloyd light palette was inspired by
[ffloyd.space](https://ffloyd.space/about); companion palettes were designed in
this workspace.
